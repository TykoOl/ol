<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Unidades de Salud</title>

    <!-- Estilos de Select2 y Leaflet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <link rel="stylesheet" href="{{ asset('css/mapa.css') }}">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="{{ asset('js/buttons.js') }}"></script>
    <script src="{{ asset('js/controllers.js') }}"></script>
</head>

<body>
    <header>
        <div class="header-top">
            <div class="logo">Buscar Unidades de Salud</div>
        </div>
    </header>

    <div class="container">
        <div class="filters">
            <h2>Filtrar Unidades de Salud</h2>

            <label for="searchJurisdiccion">Jurisdicción o Zona:</label>
            <select id="searchJurisdiccion" class="select2" style="width: 100%;"></select>

            <label for="searchMunicipio">Municipio:</label>
            <select id="searchMunicipio" class="select2" style="width: 100%;"></select>

            <label for="searchLocalidad">Localidad:</label>
            <select id="searchLocalidad" class="select2" style="width: 100%;"></select>

            <label for="searchClues">CLUES o Nombre de la Unidad:</label>
            <select id="searchClues" class="select2" style="width: 100%;"></select>

            <button id="btnGlobalSearch">Buscar</button>
            <button id="btnResetFilters">Restablecer Filtros</button>
        </div>

        <div class="map">
            <div id="map"></div>
        </div>
    </div>

    <div id="selectedInfo">
        <h3>Información de la Búsqueda</h3>
        <table id="unidadesTable" border="1">
            <thead>
                <tr>
                    <th>CLUES</th>
                    <th>Unidad Médica</th>
                    <th>Municipio</th>
                    <th>Latitud</th>
                    <th>Longitud</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>

        <div class="pagination">
            <button id="prevPage" disabled>❮</button>
            <span id="currentPage">1</span> / <span id="totalPages">1</span>
            <button id="nextPage">❯</button>
        </div>
    </div>

    <footer>
        <p>&copy; 2025 Prototipo de mapa interactivo de unidades médicas. | <a href="#">Privacidad</a> | <a href="#">Términos</a></p>
    </footer>
</body>


</html>