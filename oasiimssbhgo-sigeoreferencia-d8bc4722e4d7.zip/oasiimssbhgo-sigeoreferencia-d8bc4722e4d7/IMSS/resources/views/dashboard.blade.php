<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Panel Principal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .summary-card {
            background-color: #eaf3ea;
            border-radius: 25px;
            padding: 2px;
            text-align: center;
            cursor: pointer;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out;
        }

        .summary-card:hover {
            transform: scale(1.05);
        }

        .summary-icon {
            height: 50px;
            margin-bottom: 10px;
        }

        #detalleLista {
            max-height: 400px;
            overflow-y: auto;
        }

        #map {
            height: 80vh;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
    </style>
</head>

<body>
<a href="/busqueda" class="btn btn-outline-primary position-absolute m-3" style="top: 0; right: 0; z-index: 1050;">
        ➡️ Mapa
    </a>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Panel de Información</h1>
        <div class="row">
            <!-- Columna de tarjetas y lista -->
            <div class="col-md-4">
                @php
                $tipos = [
                'centro' => 'Centros de Salud',
                'hospital' => 'Hospitales',
                'caravana' => 'Caravanas',
                'uneme' => 'UNEMES'
                ];
                $iconos = [
                'centro' => 'Unidad.png',
                'hospital' => 'Hospital.png',
                'caravana' => 'Caravana.png',
                'uneme' => 'UNEME.png'
                ];
                @endphp

                @foreach ($tipos as $clave => $titulo)
                <div class="mb-3 summary-card tipo-card" data-tipo="{{ $clave }}">
                    <img src="{{ asset('images/' . $iconos[$clave]) }}" alt="{{ $titulo }}" class="summary-icon">
                    <p class="fw-bold fs-4 text-success mb-0">{{ $totales[$clave] ?? 0 }}</p>

                    <h5>{{ $titulo }}</h5>
                </div>
                @endforeach

                <!-- Lista desplegable -->
                <div id="detalle" class="mt-4 d-none">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h5 id="detalleTitulo" class="mb-0"></h5>
                        <button class="btn btn-sm btn-outline-danger" id="btnCerrarDetalle">Cerrar</button>
                    </div>
                    <ul id="detalleLista" class="list-group"></ul>
                </div>
            </div>

            <!-- Columna del mapa -->
            <div class="col-md-8">
                <div id="map"></div>
            </div>
        </div>
    </div>

    <!-- Leaflet -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <script>
        $(document).ready(function() {
            // Lista desplegable
            $('.tipo-card').on('click', function() {
    const tipo = $(this).data('tipo');
    const titulo = $(this).find('h5').text();
    $('#detalleTitulo').text('Unidades en: ' + titulo);
    $('#detalleLista').empty();

    // Ocultamos todos los marcadores
    Object.values(markers).flat().forEach(m => map.removeLayer(m));

    // Mostrar solo los del tipo correspondiente
    let tipoId;
    switch (tipo) {
        case 'hospital': tipoId = 3; break;
        case 'centro': tipoId = 4; break;
        case 'caravana': tipoId = 5; break;
        case 'uneme': tipoId = 7; break;
        default: tipoId = 'all';
    }

    if (markers[tipoId]) {
        markers[tipoId].forEach(m => m.addTo(map));
    }

    // Obtener lista para el detalle
    // Obtener lista para el detalle
    if (tipo === 'uneme') {
    // Obtener todas las unidades UNEME y luego filtrar las dos que necesitas
    $.get('/api/unidades-por-tipo', { tipo }, function(data) {
        const filtradas = data.filter(u =>
            u.nombre.includes('TULA') || u.nombre.includes('PACHUCA')
        );

        if (filtradas.length === 0) {
            $('#detalleLista').append('<li class="list-group-item text-danger">No hay unidades registradas</li>');
        } else {
            filtradas.forEach(unidad => {
                $('#detalleLista').append(`
                    <li class="list-group-item">
                        <strong>${unidad.clues}</strong> - ${unidad.nombre}
                        <span class="badge bg-success ms-2">Activa</span>
                    </li>
                `);
            });

            // Solo mostrar los dos marcadores deseados
            Object.values(markers).flat().forEach(m => map.removeLayer(m));

            if (markers[7]) {
                markers[7].forEach(marker => {
                    const popupContent = marker.getPopup().getContent();
                    if (
                        popupContent.includes('TULA') ||
                        popupContent.includes('PACHUCA')
                    ) {
                        marker.addTo(map);
                    }
                });
            }
        }

        if ($('#detalle').hasClass('d-none')) {
            $('#detalle').removeClass('d-none');
            $('html, body').animate({
                scrollTop: $('#detalle').offset().top - 50
            }, 400);
        }
    });
} else {
    // Para los demás tipos, comportamiento normal
    $.get('/api/unidades-por-tipo', { tipo }, function(data) {
        if (!data || data.length === 0) {
            $('#detalleLista').append('<li class="list-group-item text-danger">No hay unidades registradas</li>');
        } else {
            data.forEach(unidad => {
                $('#detalleLista').append(`
                    <li class="list-group-item">
                        <strong>${unidad.clues}</strong> - ${unidad.nombre}
                        <span class="badge bg-success ms-2">Activa</span>
                    </li>
                `);
            });
        }

        if ($('#detalle').hasClass('d-none')) {
            $('#detalle').removeClass('d-none');
            $('html, body').animate({
                scrollTop: $('#detalle').offset().top - 50
            }, 400);
        }
    });
}


            });

            $('#btnCerrarDetalle').on('click', function() {
    $('#detalle').addClass('d-none');

    if (markers['all']) {
        markers['all'].forEach(m => m.addTo(map));
    }
});


            const map = L.map('map').setView([20.489, -98.963], 8);

            const markers = {}; 
            

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap'
            }).addTo(map);

            const iconos = {
                3: L.icon({
                    iconUrl: '/images/Hospital.png',
                    iconSize: [30, 30]
                }),
                4: L.icon({
                    iconUrl: '/images/Unidad.png',
                    iconSize: [30, 30]
                }),
                5: L.icon({
                    iconUrl: '/images/Caravana.png',
                    iconSize: [30, 30]
                }),
                7: L.icon({
                    iconUrl: '/images/UNEME.png',
                    iconSize: [30, 30]
                }),
                default: L.icon({
                    iconUrl: '/images/Unidad.png',
                    iconSize: [30, 30]
                })
            };

            // Cargar unidades
            fetch('/api/unidades-mapa')
    .then(res => res.json())
    .then(data => {
        data.forEach(unidad => {
            const icono = iconos[unidad.idtipo_unidad] || iconos.default;

            const marker = L.marker([unidad.latitud, unidad.longitud], {
                icon: icono
            }).bindPopup(`<strong>${unidad.clues}</strong><br>${unidad.nombre}`);

            marker.addTo(map);

            if (!markers[unidad.idtipo_unidad]) {
                markers[unidad.idtipo_unidad] = [];
            }
            markers[unidad.idtipo_unidad].push(marker);

            if (!markers['all']) {
                markers['all'] = [];
            }
            markers['all'].push(marker);
        });
    });
        });
    </script>

</body>

</html>