<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Unidades de Salud</title>

    <!-- Estilos de Select2 y Leaflet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <link rel="stylesheet" href="{{ asset('css/mapa.css') }}">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- OpenStreetMaps -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

</head>

<body>
    <header>
        <div class="header-top">
            <div class="logo">Buscar Unidades de Salud</div>
        </div>
    </header>

    <div class="container">
        <div class="filters">
            <h2>Filtrar Unidades de Salud</h2>

            <form id="formFiltros">
                <!-- Insertando nuestro token para prevenir Cross-Site Request Forgery -->
                @csrf
                <label for="searchJurisdiccion">Jurisdicción o Zona:</label>
                <!-- Generando el Select con las Opciones de Jurisdicciones -->
                <select id="searchJurisdiccion" name="jurisdiccion" class="select2 w-100">
                    @foreach ($jurisdicciones as $jurisdiccion)
                    <option value="{{ $jurisdiccion->idjurisdiccion }}">{{ $jurisdiccion->jurisdiccion }}</option>
                    @endforeach
                </select>

                <label for="searchMunicipio">Municipio:</label>
                <!-- Generando el Select con las Opciones de Municipio -->
                <select id="searchMunicipio" name="municipio" class="select2 w-100">
                    <!-- En el select cargando el atributo jurisdicción para ocultarlo se seleccione la jurisdicción -->
                    @foreach ($municipios as $municipio)
                    <option data-jurisdiccion="{{ $municipio->idjurisdiccion }}" value="{{ $municipio->idmunicipio }}">{{ $municipio->municipio }}</option>
                    @endforeach
                </select>

                <label for="searchLocalidad">Localidad:</label>
                <!-- Generando el Select con las Opciones de Localidad -->
                <select id="searchLocalidad" name="localidad" class="select2 w-100">
                    <!-- En el select cargando el atributo municipio para ocultarlo se seleccione el municipio -->
                    @foreach ($localidades as $localidad)
                    <option data-municipio="{{ $localidad->idmunicipio }}" value="{{ $localidad->idlocalidad }}">{{ $localidad->localidad }}</option>
                    @endforeach
                </select>

                <label for="searchClues">CLUES o Nombre de la Unidad:</label>
                <!-- Generando el Select con las Opciones las Unidades -->
                <select id="searchClues" name="clues" class="select2 w-100">
                    <!-- En el select cargando el atributo municipio y localidad para ocultarlo se seleccione el municipio y/o localidad -->
                    @foreach ($unidades as $unidad)
                    <option data-municipio="{{ $unidad->idmunicipio }}" data-localidad="{{ $unidad->idlocalidad }}" value="{{ $unidad->clues }}">{{ $unidad->clues.' - '.$unidad->nombre }}</option>
                    @endforeach
                </select>

                <button type="submit" id="btnGlobalSearch">Buscar</button>
                <button id="btnResetFilters">Restablecer Filtros</button>

            </form>
        </div>

        <div class="map">
            <div id="map"></div>
        </div>
    </div>

    <div id="selectedInfo">
        <h3>Información de la Búsqueda</h3>
        <table id="unidadesTable" border="1">
            <thead>
                <tr>
                    <th>CLUES</th>
                    <th>Unidad Médica</th>
                    <th>Municipio</th>
                    <th>Latitud</th>
                    <th>Longitud</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>

        <div class="pagination">
            <button id="prevPage" disabled>❮</button>
            <span id="currentPage">1</span> / <span id="totalPages">1</span>
            <button id="nextPage">❯</button>
        </div>
    </div>

    <footer>
        <p>&copy; 2025 Prototipo de mapa interactivo de unidades médicas. | <a href="#">Privacidad</a> | <a href="#">Términos</a></p>
    </footer>
</body>

<script>
    $(document).ready(function() {
        $('.select2').select2({ //Todos los elementos con la clase Select2 se instancian con la libreria
            allowClear: true,
            placeholder: 'Seleccione...',
            templateResult: function(option, container) { //Renderiza las opciones del Select2
                if ($(option.element).hasClass('d-none')) { //Si tiene la clase para oculatarna entonces no se muestra la opción
                    return null
                }
                return option.text;
            }
        });

        $('.select2').val(null).trigger('change'); //Limpiando los valores del Select2

        $('#searchJurisdiccion').on('change', function() { //Cuando seleccionamos una jurisdiccion filtramos las opciones de los SELECTs
            let idjurisdiccion = $(this).val();

            if (idjurisdiccion == null) { //Si el valor es nulo de jurisdiccion se muestran todas las opciones
                $('#searchMunicipio').find('option').removeClass('d-none'); //Mostrando todas las opciones de los municipios
            } else {
                $('#searchMunicipio').find('option[data-jurisdiccion="' + idjurisdiccion + '"]').removeClass('d-none'); //Mostrando todas los municipios relacionados a la jurisdiccion 
                $('#searchMunicipio').find('option[data-jurisdiccion!="' + idjurisdiccion + '"]').addClass('d-none'); //Ocultando todos los municipios que no son de la jurisdiccion
            }
        });

        // seleccion de un municipio
        $('#searchMunicipio').on('change', function() {
            let idmunicipio = $(this).val(); // Obtener el ID del municipio seleccionado
            $('#searchLocalidad').empty(); // Limpiar el select de localidades

            if (!idmunicipio) return; // Si no hay municipio seleccionado, sale de la función

            // solicitud AJAX para obtener las localidades del municipio
            $.ajax({
                url: '/localidades-por-municipio', // Ruta del backend que devuelve localidades
                type: 'POST',
                data: {
                    idmunicipio: idmunicipio,
                    _token: $('input[name="_token"]').val() // Token CSRF de seguridad
                },
                success: function(response) {
                    // Agregar opción por defecto
                    $('#searchLocalidad').append('<option value="">Seleccione...</option>');

                    // Iterar sobre cada localidad recibida y agregarla al select
                    response.forEach(function(localidad) {
                        $('#searchLocalidad').append(
                            `<option value="${localidad.idlocalidad}">${localidad.localidad}</option>`
                        );
                    });

                    // Resetear valor del select
                    $('#searchLocalidad').val(null).trigger('change');
                },
                error: function() {
                    Swal.fire("Error", "No se pudieron cargar las localidades", "error");
                }
            });
        });

        // localidad
        $('#searchLocalidad').on('change', function() {
            const idjurisdiccion = $('#searchJurisdiccion').val(); // Obtener ID de jurisdicción
            const idmunicipio = $('#searchMunicipio').val(); // Obtener ID de municipio
            const idlocalidad = $(this).val(); // Obtener ID de localidad

            // Validar que los 3 filtros estén seleccionados
            if (idjurisdiccion && idmunicipio && idlocalidad) {
                $.ajax({
                    url: '/clues-por-filtros', // Ruta para obtener CLUES filtrados
                    type: 'POST',
                    data: {
                        idjurisdiccion,
                        idmunicipio,
                        idlocalidad,
                        _token: $('input[name="_token"]').val()
                    },
                    success: function(data) {
                        const $clues = $('#searchClues');
                        const currentClues = $clues.val();

                        $clues.empty();
                        $clues.append('<option></option>');

                        data.forEach(item => {
                            const nombre = item.nombre ?? 'Sin nombre';
                            $clues.append(`
            <option value="${item.clues}" data-municipio="${item.idmunicipio}" data-localidad="${item.idlocalidad}">
                ${item.clues} - ${nombre}
            </option>
        `);
                        });

                        if (currentClues && $clues.find(`option[value="${currentClues}"]`).length > 0) {
                            $clues.val(currentClues).trigger('change');
                        } else {
                            $clues.val(null).trigger('change');
                        }
                    },
                    error: function() {
                        Swal.fire("Error", "No se pudieron cargar las unidades CLUES.", "error");
                    }
                });
            }
        });

        // CLUES
        $('#searchClues').on('change', function() {
            const clues = $(this).val();
            if (!clues) return;

            $.ajax({
                url: '/buscar-filtros-por-clues',
                method: 'GET',
                data: {
                    clues
                },
                success: function(data) {
                    if (data.idjurisdiccion) {
                        // jurisdicción directamente
                        $('#searchJurisdiccion').val(data.idjurisdiccion).trigger('change');

                        // asignacion de el municipio
                        $('#searchMunicipio').val(data.idmunicipio).trigger('change');

                        // obtenemos y cargamos localidades de forma inmediata
                        $.ajax({
                            url: '/localidades-por-municipio-jurisdiccion',
                            type: 'POST',
                            data: {
                                idmunicipio: data.idmunicipio,
                                idjurisdiccion: data.idjurisdiccion,
                                _token: $('input[name="_token"]').val()
                            },
                            success: function(response) {
                                const $localidad = $('#searchLocalidad');
                                $localidad.empty().append('<option value="">Seleccione...</option>');

                                response.forEach(localidad => {
                                    $localidad.append(`<option value="${localidad.idlocalidad}">${localidad.localidad}</option>`);
                                });

                                // Ahora que están las opciones, asignamos la localidad directamente
                                $localidad.val(data.idlocalidad).trigger('change.select2');
                            },
                            error: function() {
                                Swal.fire("Error", "No se pudieron cargar las localidades", "error");
                            }
                        });
                    }
                },
                error: function() {
                    Swal.fire("Error", "No se pudo obtener información del CLUES", "error");
                }
            });
        });

        $('#formFiltros').on('submit', function(e) { //Cuando se envía el formulario lo evitamos para obtener los datos por AJAX
    e.preventDefault(); //Deshabilitando el envio del formulario

    // cambios: Si se seleccionó una localidad, hacer búsqueda por NOMBRE
    const nombreLocalidad = $('#searchLocalidad option:selected').text().trim();
    if (nombreLocalidad !== '' && nombreLocalidad !== 'Seleccione...') {
        fetch('/api/unidades/buscarPorNombreLocalidad?localidad=' + encodeURIComponent(nombreLocalidad))
            .then(response => response.json())
            .then(data => mostrarResultados(data))
            .catch(() => Swal.fire("Error", "No se pudo buscar por nombre de localidad", "error"));
        return;
    }

    if ($('#formFiltros').hasClass('submit')) { //Si se envio previamente el formulario entonces no se ejecuta el resto de código
        return false;
    }

    $('#formFiltros').addClass('submit'); //Agregando una clase al formulario para evitar multiples envios

    //Consultando la URL del JSON de unidades con sus latitudes (Esta función usa promesas, hay que tener cuidado con las peticiones asincronas)
    fetch('{{ route("api.unidades.buscar") }}', { //Configurando nuestra petición
            method: 'POST', //La petición a realizar es de tipo POST (Arquitectura REST)
            body: new FormData($('#formFiltros')[0]), //Enviando los datos del formulario
        })
        .then(response => response.json()) //Obteniendo el JSON de la respuesta del servidor
        .then(data => mostrarResultados(data))
        .catch(error => console.log(error)) //Mostrando el error en consola. Quizas se pueda mostrar al usuario...
        .finally(() => { //Quitamos la clase del formulario para habilitar de nuevo el envio
            $('#formFiltros').removeClass('submit');
        });
});


        $('#btnResetFilters').on('click', function(e) {
            e.preventDefault();
            location.reload(); // recarga la página y restaura todo al estado inicial

            $('#formFiltros')[0].reset();
            $('.select2').val(null).trigger('change');

            // Restaurar opciones de selects que se ocultaron dinámicamente
            $('#searchMunicipio option').removeClass('d-none');
            $('#searchLocalidad option').removeClass('d-none');
            $('#searchClues option').removeClass('d-none');

            // Limpiar opciones cargadas dinámicamente
            $('#searchLocalidad').empty().append('<option></option>');
            $('#searchClues').empty().append('<option></option>');

            // Limpiar mapa y tabla
            limpiarMarcadores();
            $('#unidadesTable tbody').empty();
        });

        //iconos para los marcadores
        const iconMedica = L.icon({
            iconUrl: '/images/Unidad.png', // para unidades médicas
            iconSize: [30, 30], // Tamaño del ícono
            iconAnchor: [15, 30], // Punto del ícono que está anclado al mapa
            popupAnchor: [0, -30] // Punto desde donde aparece el popup
        });

        const iconHospital = L.icon({
            iconUrl: '/images/Hospital.png', // para unidades médicas
            iconSize: [30, 30],
            iconAnchor: [15, 30],
            popupAnchor: [0, -30]
        });

        const iconCaravana = L.icon({
            iconUrl: '/images/Caravana.png', // para Caravanas
            iconSize: [30, 30],
            iconAnchor: [15, 30],
            popupAnchor: [0, -30]
        });
        const iconUneme = L.icon({
            iconUrl: '/images/UNEME.png', // para unidades médicas
            iconSize: [30, 30],
            iconAnchor: [15, 30],
            popupAnchor: [0, -30]
        });


        //Inicializando el mapa con Leaflet
        let map = L.map('map').setView([20.05, -98.21], 10);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);
        let markers = [];

        // Función para limpiar marcadores anteriores
        function limpiarMarcadores() {
            markers.forEach(marker => map.removeLayer(marker));
            markers = [];
        }

        // Función para agregar marcador en el mapa
        function agregarMarcador(lat, lng, nombre, clues, tipo) {
    let icono;

    if (tipo.includes('hospital')) {
        icono = iconHospital;
    } else if (tipo.includes('caravana')) {
        icono = iconCaravana;
    } else if (tipo.includes('uneme')) {
        icono = iconUneme;
    } else {
        icono = iconMedica;
    }

    let marker = L.marker([lat, lng], { icon: icono })
        .addTo(map)
        .bindPopup(`<b>${nombre}</b><br>CLUES: ${clues}`);
    markers.push(marker);
}

        // Función para mostrar los resultados en tabla y mapa
        function mostrarResultados(data) {
            let tableBody = $('#unidadesTable tbody');
            tableBody.empty();
            limpiarMarcadores();

            if (!data || data.length === 0) {
                Swal.fire("Sin resultados", "No se encontraron unidades con esos filtros.", "info");
                return;
            }

            data.forEach(item => {
                const nombre = item.nombre || item.unidad_medica || 'Sin nombre';
                const municipio = item.municipio || 'Sin municipio';

                tableBody.append(`
            <tr>
                <td>${item.clues}</td>
                <td>${nombre}</td>
                <td>${municipio}</td>
                <td>${item.latitud}</td>
                <td>${item.longitud}</td>
            </tr>
        `);

                if (item.latitud && item.longitud) {
                    const tipoUnidad = item.tipo_unidad?.toLowerCase() || '';
agregarMarcador(item.latitud, item.longitud, nombre, item.clues, tipoUnidad);

                }

            });
            if (markers.length > 0) {
                let group = L.featureGroup(markers);
                map.fitBounds(group.getBounds().pad(0.2));
            }
        }
    });
</script>

</html>