$(document).ready(function () {
    let cluesSeleccionado = null;
    let municipioSeleccionado = null;
    let localidadSeleccionada = null;
    let jurisdiccionSeleccionada = null;

    // Capturar selección sin ejecutar búsqueda inmediata
    $('#searchClues').on('select2:select', function (e) {
        let data = e.params.data;
        cluesSeleccionado = data.clues; // ✅ Ahora se guarda correctamente
    });
    

    $('#searchMunicipio').on('select2:select', function (e) {
        let data = e.params.data;
        municipioSeleccionado = data.text;
    });

    $('#searchLocalidad').on('select2:select', function (e) {
        let data = e.params.data;
        localidadSeleccionada = data.text;
    });

    $('#searchJurisdiccion').on('select2:select', function (e) {
        let data = e.params.data;
        jurisdiccionSeleccionada = data.id;
    });

    // **Evento del botón "Buscar"**
    $('#btnGlobalSearch').click(function () {
        // 🔥 Obtener valores directamente de los campos por si las variables no se actualizan correctamente
        let cluesSeleccionado = $('#searchClues').val();
        let municipioSeleccionado = $('#searchMunicipio').val();
        let localidadSeleccionada = $('#searchLocalidad').val();
        let jurisdiccionSeleccionada = $('#searchJurisdiccion').val();
    
        // ❌ Validación corregida: Asegurar que al menos un campo esté seleccionado
        if (!cluesSeleccionado && !municipioSeleccionado && !localidadSeleccionada && !jurisdiccionSeleccionada) {
            Swal.fire("⚠️ Atención", "Seleccione al menos un criterio de búsqueda.", "warning");
            return;
        }
    
        // ✅ Ejecutar la búsqueda según prioridad
        if (cluesSeleccionado) {
            buscarUnidadesPorClues(cluesSeleccionado);
        } else if (municipioSeleccionado) {
            buscarUnidadesPorMunicipio(municipioSeleccionado);
        } else if (localidadSeleccionada) {
            buscarUnidadesPorLocalidad(localidadSeleccionada);
        } else if (jurisdiccionSeleccionada) {
            buscarUnidadesPorJurisdiccion(jurisdiccionSeleccionada);
        }
    });
    
    

    // **Evento del botón "Restablecer Filtros"**
    $('#btnResetFilters').click(function () {
        console.log("🔄 Restableciendo filtros...");

        // Limpiar selects y variables
        $('#searchClues, #searchMunicipio, #searchLocalidad, #searchJurisdiccion').val(null).trigger('change');
        cluesSeleccionado = municipioSeleccionado = localidadSeleccionada = jurisdiccionSeleccionada = null;
        $('#selectedInfo').html('');
        clearMarkers();
        console.log("✅ Filtros restablecidos correctamente.");
    });

    // **Funciones de búsqueda AJAX**
    function buscarUnidadesPorClues(clues) {
        $.ajax({
            url: '/api/unidades/buscarClues',
            type: 'GET',
            data: { query: clues },
            dataType: 'json',
            success: function (data) {
                if (!data || data.length === 0) {
                    Swal.fire("Atención", "No se encontraron unidades con este CLUES.", "info");
                    return;
                }
                mostrarInformacion(data);
            },
            error: function () {
                Swal.fire("Error", "No se pudo realizar la búsqueda por CLUES.", "error");
            }
        });
    }

    function buscarUnidadesPorMunicipio(nombreMunicipio) {
        $.ajax({
            url: '/api/unidades/buscarUnidadesPorMunicipio',
            type: 'GET',
            data: { municipio: nombreMunicipio },
            dataType: 'json',
            success: function (data) {
                if (!data || data.length === 0) {
                    Swal.fire("Atención", "No hay unidades médicas registradas en este municipio.", "info");
                    return;
                }
                mostrarInformacion(data);
            },
            error: function () {
                Swal.fire("Error", "No se pudo realizar la búsqueda por municipio.", "error");
            }
        });
    }

    function buscarUnidadesPorLocalidad(localidadNombre) {
        $.ajax({
            url: '/api/unidades/buscarUnidadesPorLocalidad',
            type: 'GET',
            data: { localidad: localidadNombre },
            dataType: 'json',
            success: function (data) {
                if (!data || data.length === 0) {
                    Swal.fire("Atención", "No hay unidades médicas registradas en esta localidad.", "info");
                    return;
                }
                mostrarInformacion(data);
            },
            error: function () {
                Swal.fire("Error", "No se pudo realizar la búsqueda por localidad.", "error");
            }
        });
    }

    function buscarUnidadesPorJurisdiccion(idJurisdiccion) {
        $.ajax({
            url: '/api/unidades/buscarUnidadesPorJurisdiccion',
            type: 'GET',
            data: { idjurisdiccion: idJurisdiccion },
            dataType: 'json',
            success: function (data) {
                if (!data || data.length === 0) {
                    Swal.fire("⚠️ Atención", "No hay unidades médicas registradas en esta jurisdicción.", "info");
                    return;
                }
                mostrarInformacion(data);
            },
            error: function () {
                Swal.fire("❌ Error", "No se pudo realizar la búsqueda por jurisdicción.", "error");
            }
        });
    }

     function mostrarInformacion(dataArray) {
         let unidadesInfo = dataArray.map(data => `
             <p><strong>CLUES:</strong> ${data.clues || 'No disponible'}</p>
             <p><strong>Unidad Médica:</strong> ${data.unidad_medica || data.nombre || 'No disponible'}</p>
             <p><strong>Municipio:</strong> ${data.municipio || 'No disponible'}</p>
             <p><strong>Latitud:</strong> ${data.latitud || 'No disponible'}</p>
             <p><strong>Longitud:</strong> ${data.longitud || 'No disponible'}</p>
             <hr>
         `).join('');
    
         $('#selectedInfo').html(`<h3>Información de la Búsqueda</h3>${unidadesInfo}`);
    
         clearMarkers();
    
         dataArray.forEach(item => {
             if (item.latitud && item.longitud) {
                 addMarker(item.latitud, item.longitud, item.unidad_medica, item.clues);
             }
         });
    
         ajustarMapa();
     }

    function mostrarInformacion(dataArray) {
        let tableBody = $('#unidadesTable tbody');
        tableBody.empty(); // Limpiar datos anteriores
    
        if (dataArray.length === 0) {
            $('#selectedInfo').html('<h3>No se encontraron unidades médicas en esta localidad.</h3>');
            return;
        }
    
        let itemsPerPage = 5; // Número de unidades por página
        let currentPage = 1;
        let totalPages = Math.ceil(dataArray.length / itemsPerPage);
    
        function renderTable(page) {
            tableBody.empty();
            let start = (page - 1) * itemsPerPage;
            let end = start + itemsPerPage;
            let paginatedData = dataArray.slice(start, end);
    
            paginatedData.forEach(item => {
                tableBody.append(`
                    <tr>
                        <td>${item.clues || 'N/A'}</td>
                        <td>${item.unidad_medica || 'N/A'}</td>
                        <td>${item.municipio || 'N/A'}</td>
                        <td>${item.latitud || 'N/A'}</td>
                        <td>${item.longitud || 'N/A'}</td>
                    </tr>
                `);
            });
    
            $('#currentPage').text(page);
            $('#totalPages').text(totalPages);
            $('#prevPage').prop('disabled', page === 1);
            $('#nextPage').prop('disabled', page === totalPages);
        }
    
        renderTable(currentPage);
    
        $('#prevPage').off('click').on('click', function() {
            if (currentPage > 1) {
                currentPage--;
                renderTable(currentPage);
            }
        });
    
        $('#nextPage').off('click').on('click', function() {
            if (currentPage < totalPages) {
                currentPage++;
                renderTable(currentPage);
            }
        });
    
        clearMarkers();
        dataArray.forEach(item => {
            if (item.latitud && item.longitud) {
                addMarker(item.latitud, item.longitud, item.unidad_medica, item.clues);
            }
        });
    
        ajustarMapa();
    }
    
    

    console.log("✅ Filtros de búsqueda configurados correctamente.");
});
