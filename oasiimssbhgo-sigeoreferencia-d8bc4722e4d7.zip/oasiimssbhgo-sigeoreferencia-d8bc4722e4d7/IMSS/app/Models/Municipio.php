<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Municipio extends Model
{
    use \Awobaz\Compoships\Compoships;
    
    protected $table = 'municipios';

    protected $primaryKey = 'idmunicipio';

    public $incrementing = false;

    public $timestamps = false;

    protected $fillable = [
        'idmunicipio',
        'municipio',
        'idestado',
        'idjurisdiccion'
    ];

    public function estado() {
        return $this->belongsTo(Estado::class, 'idestado', 'idestado');
    }

    public function jurisdiccion() {
        return $this->belongsTo(Jurisdiccion::class, ['idestado', 'idjurisdiccion'], ['idestado', 'idjurisdiccion']);
    }

    public function localidades() {
        return $this->hasMany(Localidad::class,  ['idestado', 'idmunicipio'],  ['idestado', 'idmunicipio']);
    }
}
