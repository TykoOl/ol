<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\Unidad;
use Illuminate\Support\Facades\Log;
use App\Models\TipoUnidad;

use Illuminate\Http\Request;



//Consulta para buscar unidades por clues
class ClueController extends Controller
{
    public function buscarClues(Request $request)
    {
        $query = $request->input('query');

        if (!$query) {
            return response()->json([]);
        }

        try {
            $unidades = DB::table('unidades as u')
                ->join('localidades as l', function ($join) {
                    $join->on('l.idestado', '=', 'u.idestado')
                        ->on('l.idmunicipio', '=', 'u.idmunicipio')
                        ->on('l.idlocalidad', '=', 'u.idlocalidad');
                })
                ->join('municipios as m', function ($join) {
                    $join->on('m.idestado', '=', 'l.idestado')
                        ->on('m.idmunicipio', '=', 'l.idmunicipio');
                })
                ->join('jurisdicciones as j', function ($join) {
                    $join->on('j.idestado', '=', 'm.idestado')
                        ->on('j.idjurisdiccion', '=', 'm.idjurisdiccion');
                })
                ->where(function ($queryBuilder) use ($query) {
                    $queryBuilder->where('u.clues', 'LIKE', "%{$query}%")
                        ->orWhere('u.nombre', 'LIKE', "%{$query}%");
                })
                ->limit(10)
                ->select(
                    'u.clues',
                    'u.nombre as unidad_medica',
                    'u.latitud',
                    'u.longitud',
                    'u.idmunicipio',
                    'm.municipio as nombre_municipio',
                    'u.idlocalidad',
                    'l.localidad as nombre_localidad',
                    'm.idjurisdiccion',
                    'j.jurisdiccion as nombre_jurisdiccion'
                )
                ->get();

            $resultados = $unidades->map(function ($unidad) {
                return [
                    'id' => $unidad->clues,
                    'nombre' => $unidad->unidad_medica,
                    'clues' => $unidad->clues,
                    'latitud' => $unidad->latitud,
                    'longitud' => $unidad->longitud,
                    'idmunicipio' => $unidad->idmunicipio,
                    'municipio' => $unidad->nombre_municipio,
                    'idlocalidad' => $unidad->idlocalidad,
                    'localidad' => $unidad->nombre_localidad,
                    'idjurisdiccion' => $unidad->idjurisdiccion,
                    'jurisdiccion' => $unidad->nombre_jurisdiccion
                ];
            });

            return response()->json($resultados);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Error en la consulta: ' . $e->getMessage()
            ], 500);
        }
    }

    // Consulta para buscar jurisdicción y unidades médicas asociadas a un municipio con coordenadas
    public function buscarUnidadesPorMunicipio(Request $request)
    {
        $nombreMunicipio = $request->input('municipio');

        if (!$nombreMunicipio) {
            return response()->json(['error' => 'Falta el nombre del municipio'], 400);
        }

        try {
            $unidades = DB::table('unidades as u')
                ->join('municipios as m', function ($join) {
                    $join->on('m.idestado', '=', 'u.idestado')
                        ->on('m.idmunicipio', '=', 'u.idmunicipio');
                })
                ->where('m.municipio', 'LIKE', "%{$nombreMunicipio}%")
                ->select(
                    'u.clues',
                    'u.nombre as unidad_medica',
                    'm.municipio',
                    'm.idmunicipio',
                    'm.idjurisdiccion',
                    'm.idestado',
                    'u.latitud',
                    'u.longitud'
                )
                ->get();

            if ($unidades->isEmpty()) {
                return response()->json(['message' => 'No se encontraron unidades en este municipio'], 404);
            }

            return response()->json($unidades);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error en la consulta: ' . $e->getMessage()], 500);
        }
    }

    public function buscarUnidades(Request $request)
    {
        try {
            $query = DB::table('unidades as u')
                ->join('municipios as m', 'u.idmunicipio', '=', 'm.idmunicipio')
                ->join('tipos_unidades as t', 'u.idtipo_unidad', '=', 't.idtipo_unidad');

            if ($request->filled('clues')) {
                $query->where('u.clues', $request->clues);
            }

            if ($request->filled('municipio')) {
                $query->where('m.idmunicipio', $request->municipio);
            }

            if ($request->filled('localidad')) {
                $query->where('u.idlocalidad', $request->localidad);
            }

            if ($request->filled('jurisdiccion')) {
                $query->where('m.idjurisdiccion', $request->jurisdiccion);
            }


            $unidades = $query->select(
                'u.clues',
                'u.nombre as unidad_medica',
                'u.latitud',
                'u.longitud',
                'm.municipio',
                't.tipo_unidad'
            )->get();

            return response()->json($unidades);
        } catch (\Throwable $e) {
            Log::error('Error en buscarUnidades: ' . $e->getMessage());
            return response()->json(['error' => 'Error en el servidor'], 500);
        }
    }



    public function buscarMunicipiosConUnidades(Request $request)
    {
        $query = $request->input('query');

        $municipios = DB::table('municipios as m')
            ->leftJoin('unidades as u', 'm.idmunicipio', '=', 'u.idmunicipio')
            ->select('m.idmunicipio', 'm.municipio', 'm.idestado', 'm.idjurisdiccion')
            ->distinct()
            ->orderBy('m.municipio');

        if ($query) {
            $municipios->where('m.municipio', 'LIKE', "%{$query}%");
        }

        return response()->json($municipios->get());
    }



    public function buscarJurisdicciones(Request $request)
    {
        try {
            $jurisdicciones = DB::table('jurisdicciones')
                ->select('idjurisdiccion', 'jurisdiccion')
                ->where('jurisdiccion', 'LIKE', "%" . $request->query('query') . "%")
                ->limit(10)
                ->get();

            return response()->json($jurisdicciones);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error en la consulta: ' . $e->getMessage()], 500);
        }
    }
    public function buscarUnidadesPorJurisdiccion(Request $request)
    {
        $idjurisdiccion = $request->input('idjurisdiccion');

        if (!$idjurisdiccion) {
            return response()->json(['error' => 'Falta el parámetro idjurisdiccion'], 400);
        }

        $unidades = DB::table('unidades as u')
            ->join('municipios as m', 'u.idmunicipio', '=', 'm.idmunicipio')
            ->join('jurisdicciones as j', 'm.idjurisdiccion', '=', 'j.idjurisdiccion')
            ->where('j.idjurisdiccion', $idjurisdiccion)
            ->select(
                'u.clues',
                'u.nombre as unidad_medica',
                'm.municipio',
                'u.latitud',
                'u.longitud'
            )
            ->get();

        if ($unidades->isEmpty()) {
            return response()->json(['error' => 'No se encontraron unidades en esta jurisdicción'], 404);
        }

        return response()->json($unidades);
    }

    public function buscarLocalidadesConUnidades(Request $request)
    {
        $query = $request->input('query');

        try {
            $localidades = DB::table('localidades as l')
                ->join('unidades as u', function ($join) {
                    $join->on('l.idestado', '=', 'u.idestado')
                        ->on('l.idmunicipio', '=', 'u.idmunicipio')
                        ->on('l.idlocalidad', '=', 'u.idlocalidad');
                })
                ->select('l.idlocalidad', 'l.localidad')
                ->distinct()
                ->orderBy('l.localidad');

            if ($query) {
                $localidades->where('l.localidad', 'LIKE', "%{$query}%");
            }

            return response()->json($localidades->get());
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error en la consulta: ' . $e->getMessage()], 500);
        }
    }



    public function buscarMunicipiosPorJurisdiccion(Request $request)
    {
        $municipios = DB::table('municipios')
            ->where('idjurisdiccion', $request->idjurisdiccion)
            ->select('idmunicipio', 'municipio')
            ->get();

        return response()->json($municipios);
    }
    public function buscarLocalidadesPorMunicipio(Request $request)
    {
        $nombreMunicipio = $request->input('municipio');

        if (!$nombreMunicipio) {
            return response()->json(['error' => 'Falta el nombre del municipio'], 400);
        }

        try {
            $localidades = DB::table('localidades as l')
                ->join('municipios as m', function ($join) {
                    $join->on('m.idestado', '=', 'l.idestado')
                        ->on('m.idmunicipio', '=', 'l.idmunicipio');
                })
                ->where('m.municipio', 'LIKE', "%{$nombreMunicipio}%") // Búsqueda por nombre
                ->select('l.idlocalidad', 'l.localidad')
                ->distinct()
                ->orderBy('l.localidad')
                ->get();

            return response()->json($localidades);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error en la consulta: ' . $e->getMessage()], 500);
        }
    }

    public function buscarLocalidadesPorNombreMunicipio(Request $request)
    {
        $nombreMunicipio = $request->input('municipio');

        if (!$nombreMunicipio) {
            return response()->json(['error' => 'Falta el nombre del municipio'], 400);
        }

        try {
            $localidades = DB::table('localidades as l')
                ->join('municipios as m', function ($join) {
                    $join->on('m.idestado', '=', 'l.idestado')
                        ->on('m.idmunicipio', '=', 'l.idmunicipio');
                })
                ->where('m.municipio', 'LIKE', "%{$nombreMunicipio}%") // Búsqueda por nombre
                ->select('l.idlocalidad', 'l.localidad')
                ->distinct()
                ->orderBy('l.localidad')
                ->get();

            return response()->json($localidades);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error en la consulta: ' . $e->getMessage()], 500);
        }
    }


    public function obtenerLocalidadesPorMunicipio(Request $request)
    {
        $idmunicipio = $request->input('idmunicipio');

        if (!$idmunicipio) {
            return response()->json(['error' => 'Falta el ID del municipio'], 400);
        }

        $localidades = DB::table('localidades')
            ->where('idmunicipio', $idmunicipio)
            ->select('idlocalidad', 'localidad')
            ->orderBy('localidad')
            ->get();

        return response()->json($localidades);
    }

    public function buscarLocalidadesPorMunicipioYJurisdiccion(Request $request)
    {
        $idmunicipio = $request->input('idmunicipio');
        $idjurisdiccion = $request->input('idjurisdiccion');

        if (!$idmunicipio || !$idjurisdiccion) {
            return response()->json(['error' => 'Faltan parámetros'], 400);
        }

        try {
            $localidades = DB::table('localidades as l')
                ->join('municipios as m', function ($join) {
                    $join->on('m.idestado', '=', 'l.idestado')
                        ->on('m.idmunicipio', '=', 'l.idmunicipio');
                })
                ->where('l.idmunicipio', $idmunicipio)
                ->where('m.idjurisdiccion', $idjurisdiccion)
                ->select('l.idlocalidad', 'l.localidad')
                ->orderBy('l.localidad')
                ->distinct()
                ->get();

            return response()->json($localidades);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error en la consulta: ' . $e->getMessage()], 500);
        }
    }

    public function buscarCluesPorFiltros(Request $request)
    {
        $query = DB::table('unidades as u')
            ->join('localidades as l', function ($join) {
                $join->on('u.idestado', '=', 'l.idestado')
                    ->on('u.idmunicipio', '=', 'l.idmunicipio')
                    ->on('u.idlocalidad', '=', 'l.idlocalidad');
            })
            ->join('municipios as m', function ($join) {
                $join->on('m.idestado', '=', 'l.idestado')
                    ->on('m.idmunicipio', '=', 'l.idmunicipio');
            });

        if ($request->filled('idjurisdiccion')) {
            $query->where('m.idjurisdiccion', $request->idjurisdiccion);
        }

        if ($request->filled('idmunicipio')) {
            $query->where('u.idmunicipio', $request->idmunicipio);
        }

        if ($request->filled('idlocalidad')) {
            $query->where('u.idlocalidad', $request->idlocalidad);
        }

        $clues = $query->select('u.clues', 'u.nombre', 'u.idmunicipio', 'u.idlocalidad')
            ->orderBy('u.nombre')
            ->get();

        return response()->json($clues);
    }

    public function obtenerFiltrosPorClues(Request $request)
    {
        $clues = $request->query('clues');

        $unidad = DB::table('unidades as u')
            ->join('localidades as l', function ($join) {
                $join->on('u.idestado', '=', 'l.idestado')
                    ->on('u.idmunicipio', '=', 'l.idmunicipio')
                    ->on('u.idlocalidad', '=', 'l.idlocalidad');
            })
            ->join('municipios as m', function ($join) {
                $join->on('m.idestado', '=', 'l.idestado')
                    ->on('m.idmunicipio', '=', 'l.idmunicipio');
            })
            ->join('jurisdicciones as j', function ($join) {
                $join->on('j.idestado', '=', 'm.idestado')
                    ->on('j.idjurisdiccion', '=', 'm.idjurisdiccion');
            })
            ->where('u.clues', $clues)
            ->select(
                'u.clues',
                'u.nombre',
                'u.idlocalidad',
                'u.idmunicipio',
                'm.idjurisdiccion'
            )
            ->first();

        return response()->json($unidad);
    }


    public function obtener_unidades(Request $request)
    {
        $unidades = Unidad::select('clues', 'nombre', 'latitud', 'longitud')
            ->when(isset($request->clues), function ($query) use ($request) { //Si recibimos datos de la CLUES, entonces buscamos por CLUES
                $query->where('clues', $request->clues); //select * from unidades where clues = ?
            })->when(isset($request->municipio), function ($query) use ($request) { //Si recibimos el ID del municipio entonces filtramos por municipio
                $query->whereHas('localidad.municipio', function ($query) use ($request) { //Buscamos en la localidad y municipio ligados a la unidad
                    $query->where('idmunicipio', $request->municipio);
                });
            })->when(isset($request->jurisdiccion), function ($query) use ($request) { //Si recibimos el ID de la jurisdiccion, entonces filtramos por su ID
                $query->whereHas('localidad.municipio.jurisdiccion', function ($query) use ($request) { //Buscamos en la localidad y municipio ligados a la unidad
                    $query->where('idjurisdiccion', $request->jurisdiccion);
                });
            })->where('idstatus_unidad', 1) //Buscando solo unidades activas
            ->get();

        return response()->json($unidades);
    }

    // Consulta para obtener el dashboard
    public function dashboard()
{
    $totales = [
        'centro' => Unidad::where('idstatus_unidad', 1)
            ->whereHas('tipoUnidad', fn($q) => 
                $q->where('idtipo_unidad', 4)
                  ->where('tipo_unidad', 'like', '%Centro de Salud%')
            )->count(),

        'hospital' => Unidad::where('idstatus_unidad', 1)
            ->whereHas('tipoUnidad', fn($q) => 
                $q->where('idtipo_unidad', 3)
                  ->where('tipo_unidad', 'like', '%Hospital%')
            )->count(),

        'caravana' => Unidad::where('idstatus_unidad', 1)
            ->whereHas('tipoUnidad', fn($q) => 
                $q->where('idtipo_unidad', 5)
                  ->where('tipo_unidad', 'like', '%Caravana%')
            )->count(),

        'uneme' => Unidad::where('idstatus_unidad', 1)
            ->where('idtipologia_unidad', 23) // Asumo que idtipologia_unidad es el identificador de "UNEME"
            ->where('idsubtipologia', 8) // idsubtipologia correspondiente a UNEME
            ->count(),
    ];

    return view('dashboard', compact('totales'));
}


    public function unidadesPorTipo(Request $request)
    {
        $tipo = $request->input('tipo');
    
        $query = Unidad::with('tipoUnidad')
            ->where('idstatus_unidad', 1) // Solo unidades activas
            ->select('clues', 'nombre');
    
        if ($tipo === 'uneme') {
            $query->where('idsubtipologia', 8)
                  ->where('idtipologia_unidad', 23)
                  ->whereIn('idsubtipologia', [7, 8, 9, 10, 11, 12]);
        } else {
            $query->whereHas('tipoUnidad', fn($q) =>
                $q->where('tipo_unidad', 'like', "%$tipo%"));
        }
    
        $unidades = $query->get();
    
        return response()->json($unidades);
    }
    

    // Para mostrar los totales en el dashboard (solo unidades activas con status 1)


    // Consulta para obtener todas las unidades con coordenadas
    public function unidadesConCoordenadas(Request $request)
{
    $tipo = $request->input('tipo'); // Puede venir como 'UNEMES'

    $query = Unidad::with('tipoUnidad')
        ->whereNotNull('latitud')
        ->whereNotNull('longitud')
        ->where('idstatus_unidad', 1);

    if ($tipo) {
        $query->whereHas('tipoUnidad', fn($q) =>
            $q->where('tipo_unidad', 'like', "%$tipo%"));
    }

    $unidades = $query->select('clues', 'nombre', 'latitud', 'longitud', 'idtipo_unidad')
        ->get();

    return response()->json($unidades);
}


    public function buscarPorNombreLocalidad(Request $request)
    {
        $nombreLocalidad = $request->input('localidad');

        if (!$nombreLocalidad) {
            return response()->json(['error' => 'Falta el nombre de la localidad'], 400);
        }

        try {
            $unidades = DB::table('unidades as u')
                ->join('localidades as l', function ($join) {
                    $join->on('u.idestado', '=', 'l.idestado')
                        ->on('u.idmunicipio', '=', 'l.idmunicipio')
                        ->on('u.idlocalidad', '=', 'l.idlocalidad');
                })
                ->join('municipios as m', function ($join) {
                    $join->on('m.idestado', '=', 'l.idestado')
                        ->on('m.idmunicipio', '=', 'l.idmunicipio');
                })
                ->where('l.localidad', 'LIKE', '%' . $nombreLocalidad . '%')
                ->where('u.idstatus_unidad', 1)
                ->select(
                    'u.clues',
                    'u.nombre as unidad_medica',
                    'u.latitud',
                    'u.longitud',
                    'm.municipio',
                    'l.localidad as nombre_localidad'
                )
                ->orderBy('u.nombre')
                ->get();

            return response()->json($unidades);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Error en la consulta: ' . $e->getMessage()], 500);
        }
    }

    public function obtenerUnemesEspecificos()
{
    $nombres = [
        'UNEME ENFERMEDADES CRÓNICAS TULA',
        'UNEME EC PACHUCA'
    ];

    $unidades = Unidad::whereIn('nombre', $nombres)->get();

    return response()->json($unidades);
}

}
