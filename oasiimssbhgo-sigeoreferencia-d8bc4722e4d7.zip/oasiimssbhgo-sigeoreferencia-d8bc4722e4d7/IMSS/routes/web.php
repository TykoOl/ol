<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\JsonController;
use App\Http\Controllers\ClueController;
use App\Models\Jurisdiccion;
use App\Models\Municipio;
use App\Models\Localidad;
use App\Models\Unidad;


Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
});

Route::get('/dashboard', [ClueController::class, 'dashboard']);




Route::get('/busqueda', function () {
    $jurisdicciones = Jurisdiccion::select('idjurisdiccion', 'jurisdiccion')->get(); //Obteniendo todas las jurisdicciones con su ID y descripción
    $municipios = Municipio::select('idjurisdiccion', 'idmunicipio', 'municipio')->get(); //Obteniendo todos los municipios con jurisdiccion, ID y descripción
    $localidades = Localidad::select('idmunicipio', 'idlocalidad', 'localidad')->get(); //Obteniendo todas las localidades con municipio, ID y descripción
    $unidades = Unidad::select('idmunicipio', 'idlocalidad', 'clues', 'nombre')->where('idstatus_unidad', 1)->get(); //Obteniendo todas las unidades con su municipiuo, localidad, clues y nombre

    return view('busqueda', compact('jurisdicciones', 'municipios', 'localidades', 'unidades'));
});

// Ruta para buscar unidades dependiendo de varios parametros
Route::post('/api/unidades/buscar', [ClueController::class, 'obtener_unidades'])->name('api.unidades.buscar');

// Ruta para la búsqueda por CLUES
Route::get('/api/unidades/buscarClues', [ClueController::class, 'buscarClues']);

// Ruta para la búsqueda por Municipio
Route::get('/api/unidades/buscarUnidadesPorMunicipio', [ClueController::class, 'buscarUnidadesPorMunicipio']);

// Ruta para la búsqueda por Jurisdicción Sanitaria II Tulancingo
Route::get('/api/unidades/buscarUnidadesTulancingo', [ClueController::class, 'buscarUnidadesTulancingo']);



Route::get('/api/unidades/buscarMunicipiosConUnidades', [ClueController::class, 'buscarMunicipiosConUnidades']);
Route::get('/api/unidades/buscarJurisdicciones', [ClueController::class, 'buscarJurisdicciones']);
Route::get('/api/unidades/buscarUnidadesPorJurisdiccion', [ClueController::class, 'buscarUnidadesPorJurisdiccion']);

Route::get('/unidades/buscarMunicipiosConUnidades', [ClueController::class, 'buscarMunicipiosConUnidades']);

Route::get('/unidades/buscarLocalidadesConUnidades', [ClueController::class, 'buscarLocalidadesConUnidades']);
Route::get('/api/unidades/buscarLocalidadesConUnidades', [ClueController::class, 'buscarLocalidadesConUnidades']);
Route::get('/unidades/buscarMunicipiosPorJurisdiccion', [ClueController::class, 'buscarMunicipiosPorJurisdiccion']);

Route::get('/api/unidades/buscarMunicipiosPorJurisdiccion', [ClueController::class, 'buscarMunicipiosPorJurisdiccion']);
Route::get('/api/unidades/buscarLocalidadesPorMunicipio', [ClueController::class, 'buscarLocalidadesPorMunicipio']);
Route::get('/api/unidades/buscarLocalidadesPorNombreMunicipio', [ClueController::class, 'buscarLocalidadesPorNombreMunicipio']);


Route::get('/api/unidades/buscarCluesPorLocalidad', [ClueController::class, 'buscarCluesPorLocalidad']);
Route::get('/api/unidades/buscarUnidades', [ClueController::class, 'buscarUnidades']);

Route::get('/unidades/buscarCluesPorLocalidad', [ClueController::class, 'buscarCluesPorLocalidad']);
Route::get('/unidades/buscarUnidadesPorLocalidad', [ClueController::class, 'buscarUnidadesPorLocalidad']);
Route::get('/unidades/buscarLocalidadesPorMunicipio', [ClueController::class, 'buscarLocalidadesPorMunicipio']);
Route::get('/unidades/buscarLocalidadesPorNombreMunicipio', [ClueController::class, 'buscarLocalidadesPorNombreMunicipio']);


//
Route::post('/localidades-por-municipio', [ClueController::class, 'obtenerLocalidadesPorMunicipio']);
Route::post('/clues-por-filtros', [ClueController::class, 'buscarCluesPorFiltros']);
Route::get('/buscar-filtros-por-clues', [ClueController::class, 'obtenerFiltrosPorClues']);
Route::post('/localidades-por-municipio-jurisdiccion', [ClueController::class, 'buscarLocalidadesPorMunicipioYJurisdiccion']);
Route::post('/api/unidades/buscar', [ClueController::class, 'buscarUnidades'])->name('api.unidades.buscar');

Route::get('/api/unidades-por-tipo', [ClueController::class, 'unidadesPorTipo']);
Route::get('/api/unidades-por-tipo', [ClueController::class, 'unidadesPorTipo'])->name('api.unidades.tipo');
Route::get('/inicio', [ClueController::class, 'dashboard'])->name('dashboard');

Route::get('/api/unidades-mapa', [ClueController::class, 'unidadesConCoordenadas']);
Route::post('/buscar-por-localidad', [ClueController::class, 'buscarPorLocalidad']);

Route::get('/api/unidades/buscarPorNombreLocalidad', [ClueController::class, 'buscarPorNombreLocalidad']);
Route::get('/api/unidades-con-coordenadas', [ClueController::class, 'unidadesConCoordenadas']);

Route::get('/api/unemes-especificos', [ClueController::class, 'obtenerUnemesEspecificos']);
